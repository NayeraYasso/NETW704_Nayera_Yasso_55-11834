package com.example.milestone1

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.auth.EmailAuthProvider


class User : Fragment() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var genderEditText: EditText
    private lateinit var userTypeEditText: EditText
    private lateinit var saveButton: Button





    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_user, container, false)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")

        nameEditText = rootView.findViewById(R.id.nameTextView)
        emailEditText = rootView.findViewById(R.id.emailTextView)
        genderEditText = rootView.findViewById(R.id.genderTextView)
        userTypeEditText = rootView.findViewById(R.id.userTypeTextView)
        saveButton = rootView.findViewById(R.id.saveButton)




        fetchUserData()

        saveButton.setOnClickListener {
            saveUserData()
        }

        return rootView
    }

    private fun fetchUserData() {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            database.child(userId).get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userMap = task.result?.value as? Map<String, Any>
                    if (userMap != null) {
                        val name = userMap["name"] as? String ?: ""
                        nameEditText.setText(name)
                        emailEditText.setText(userMap["email"] as? String ?: "")
                        genderEditText.setText(userMap["gender"] as? String ?: "")
                        userTypeEditText.setText(userMap["userType"] as? String ?: "")


                    } else {
                        Toast.makeText(context, "User data not found", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch data: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else {
            Toast.makeText(context, "User not authenticated", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveUserData() {
        val userId = auth.currentUser?.uid
        val currentUser = auth.currentUser

        if (userId != null && currentUser != null) {
            val updatedName = nameEditText.text.toString()
            val updatedEmail = emailEditText.text.toString()
            val updatedGender = genderEditText.text.toString().capitalize() // Capitalize first letter
            val updatedUserType = userTypeEditText.text.toString().capitalize() // Capitalize first letter

            // Validate inputs
            if (updatedName.isBlank() || updatedEmail.isBlank() || updatedGender.isBlank() || updatedUserType.isBlank()) {
                Toast.makeText(context, "All fields must be filled.", Toast.LENGTH_SHORT).show()
                return
            }

            // Validate gender
            if (updatedGender !in listOf("Male", "Female")) {
                Toast.makeText(context, "Gender must be 'Male' or 'Female'.", Toast.LENGTH_SHORT).show()
                return
            }

            // Validate userType
            if (updatedUserType !in listOf("Doctor", "Patient")) {
                Toast.makeText(context, "User type must be 'Doctor' or 'Patient'.", Toast.LENGTH_SHORT).show()
                return
            }

            // If all inputs are valid, proceed with re-authentication
            val passwordInput = EditText(context)
            passwordInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

            AlertDialog.Builder(context)
                .setTitle("Re-authenticate")
                .setMessage("Please enter your password to update your email.")
                .setView(passwordInput)
                .setPositiveButton("Confirm") { _, _ ->
                    val password = passwordInput.text.toString()
                    val credential = EmailAuthProvider.getCredential(currentUser.email!!, password)

                    currentUser.reauthenticate(credential)
                        .addOnSuccessListener {
                            currentUser.updateEmail(updatedEmail)
                                .addOnSuccessListener {
                                    val updatedData = mapOf(
                                        "name" to updatedName,
                                        "email" to updatedEmail,
                                        "gender" to updatedGender,
                                        "userType" to updatedUserType
                                    )

                                    // Update data in the database
                                    database.child(userId).updateChildren(updatedData)
                                        .addOnSuccessListener {
                                            Toast.makeText(context, "User data updated successfully.", Toast.LENGTH_SHORT).show()
                                        }
                                        .addOnFailureListener { exception ->
                                            Toast.makeText(context, "Failed to update data: ${exception.message}", Toast.LENGTH_LONG).show()
                                            Log.e("UpdateError", "Failed to update data in DB: ${exception.message}")
                                        }
                                }
                                .addOnFailureListener { exception ->
                                    Toast.makeText(context, "Failed to update email: ${exception.message}", Toast.LENGTH_LONG).show()
                                    Log.e("EmailUpdateError", "Failed to update email: ${exception.message}")
                                }
                        }
                        .addOnFailureListener { exception ->
                            Toast.makeText(context, "Re-authentication failed: ${exception.message}", Toast.LENGTH_LONG).show()
                            Log.e("ReauthError", "Re-authentication failed: ${exception.message}")
                        }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            Toast.makeText(context, "User not authenticated", Toast.LENGTH_LONG).show()
        }
    }

}