package com.example.milestone1

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.milestone1.m2.Doctor
import com.example.milestone1.models.DataClassDoctors
import com.example.milestone1.models.DataClassPatients
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class signup : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth  // Firebase Authentication reference
    private lateinit var database: DatabaseReference  // Firebase Realtime Database reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        // Initialize Firebase Auth and Database
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")

        val nameInput = findViewById<EditText>(R.id.name)
        val emailInput = findViewById<EditText>(R.id.email)
        val passwordInput = findViewById<EditText>(R.id.password)
        val userInput = findViewById<EditText>(R.id.user)
        val genderInput = findViewById<EditText>(R.id.gender)
        val signUpButton = findViewById<ImageView>(R.id.signinbut)

        signUpButton.setOnClickListener {
            val name = nameInput.text.toString()
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()
            val userType = userInput.text.toString().trim().lowercase()
            val gender = genderInput.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && userType.isNotEmpty() && gender.isNotEmpty()) {
                signUp(name, email, password, userType, gender)
            } else {
                Toast.makeText(this, "Please fill in all the fields.", Toast.LENGTH_SHORT).show()
            }
        }

        val forgetTextView = findViewById<TextView>(R.id.textrec)
        forgetTextView.setOnClickListener {
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        }
    }

    private fun signUp(name: String, email: String, password: String, userType: String, gender: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show()

                    // Get the current user ID from FirebaseAuth
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        // Call saveUserData to store the user details in the database
                        saveUserData(userId, name, email, password ,userType, gender)
                    }

                    // Choose activity based on user type
                    val intent = if (userType == "patient") {
                        Intent(this, profile::class.java)
                    } else if (userType == "doctor") {
                        Intent(this, Doctor::class.java)
                    } else {
                        Toast.makeText(this, "Invalid user type. Please enter 'Patient' or 'Doctor'.", Toast.LENGTH_SHORT).show()
                        return@addOnCompleteListener
                    }

                    // Pass user data to the selected activity
                    intent.putExtra("name", name)
                    intent.putExtra("email", email)
                    intent.putExtra("password", password)
                    intent.putExtra("userType", userType)
                    intent.putExtra("gender", gender)
                    startActivity(intent)
                    finish()
                } else {
                    val exception = task.exception
                    if (exception is FirebaseAuthUserCollisionException) {
                        Toast.makeText(this, "Email is already registered. Try signing in.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Account creation failed: ${exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }

    // Function to save user data to Firebase Realtime Database
    private fun saveUserData(userId: String, name: String, email: String, password: String ,userType: String, gender: String) {
        var Questions: MutableList<String> = mutableListOf()  // Array of questions
        var Responses: MutableList<String> = mutableListOf()
        var notification = false  // Example notification flag
        var pending = false  // Example pending flag

        // Add "nay" to the first cell of the questions list
        Questions.add("Questions below")

        // Add "nay" to the first cell of the responses list as well
        Responses.add("Responses below")

        // If the user is a doctor, create a DataClassDoctors object
        val user = if (userType == "doctor") {
            DataClassDoctors(name, email, password, 'D', gender[0], Questions, Responses, notification, pending)
        } else {
            // Generate a patient ID and create DataClassPatients object
            val patientId = userId  // You can use the Firebase User ID as the patient ID
            DataClassPatients(patientId,name, email, password, 'P', gender[0], Questions, Responses, notification, pending)
        }

        val userMap = mapOf(
            "name" to name,
            "email" to email,
            "password" to password,
            "userType" to userType,
            "gender" to gender,
            "questions" to Questions,
            "responses" to Responses,
            "notification" to notification,
            "pending" to pending,
            "patientId" to (if (userType == "patient") userId else null)  // Save the patient ID if the user is a patient
        )

        // Save user data in the "Users" node with userId as key
        database.child(userId).setValue(userMap)
            .addOnSuccessListener {
                Toast.makeText(this, "User data saved successfully.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to save user data: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
