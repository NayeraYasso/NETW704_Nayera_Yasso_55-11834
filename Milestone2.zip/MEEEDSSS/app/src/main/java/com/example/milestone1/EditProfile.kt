package com.example.milestone1

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class EditProfile : AppCompatActivity() {

    private lateinit var nameTextView: EditText
    private lateinit var emailTextView: EditText
    private lateinit var genderTextView: EditText
    private lateinit var userTypeTextView: EditText
    private lateinit var saveButton: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Initialize UI elements
        nameTextView = findViewById(R.id.nameTextView)
        emailTextView = findViewById(R.id.emailTextView)
        genderTextView = findViewById(R.id.genderTextView)
        userTypeTextView = findViewById(R.id.userTypeTextView)
        saveButton = findViewById(R.id.saveButton)

        // Initialize Firebase
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Fetch user data if authenticated
        val currentUser = auth.currentUser
        if (currentUser != null) {
            fetchUserData(currentUser.uid)
        } else {
            Toast.makeText(this, "User not authenticated.", Toast.LENGTH_SHORT).show()
        }

        // Set up Save button listener
        saveButton.setOnClickListener {
            if (currentUser != null) {
                saveUserData(currentUser.uid)
            }
        }
    }

    private fun fetchUserData(userId: String) {
        database.child("Users").child(userId).get().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val userMap = task.result?.value as? Map<String, Any>
                if (userMap != null) {
                    // Populate fields with user data
                    nameTextView.setText(userMap["name"] as? String ?: "")
                    emailTextView.setText(userMap["email"] as? String ?: "")
                    genderTextView.setText(userMap["gender"] as? String ?: "")
                    userTypeTextView.setText(userMap["userType"] as? String ?: "")
                    userTypeTextView.isEnabled = true // Enable userType field
                } else {
                    Toast.makeText(this, "User data not found.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Failed to fetch data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Error fetching data: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveUserData(userId: String) {
        val updatedName = nameTextView.text.toString()
        val updatedEmail = emailTextView.text.toString()
        val updatedGender = genderTextView.text.toString().capitalize() // Capitalize first letter
        val updatedUserType = userTypeTextView.text.toString().capitalize() // Capitalize first letter

        // Validate inputs
        if (updatedName.isBlank() || updatedEmail.isBlank() || updatedGender.isBlank() || updatedUserType.isBlank()) {
            Toast.makeText(this, "All fields must be filled.", Toast.LENGTH_SHORT).show()
            return
        }

        // Validate gender
        if (updatedGender !in listOf("Male", "Female")) {
            Toast.makeText(this, "Gender must be 'Male' or 'Female'.", Toast.LENGTH_SHORT).show()
            return
        }

        // Validate userType
        if (updatedUserType !in listOf("Doctor", "Patient")) {
            Toast.makeText(this, "User type must be 'Doctor' or 'Patient'.", Toast.LENGTH_SHORT).show()
            return
        }

        // Prompt for reauthentication if email is being updated
        if (updatedEmail != auth.currentUser?.email) {
            reauthenticateAndUpdateEmail(updatedEmail, updatedName, updatedGender, updatedUserType, userId)
        } else {
            updateUserProfile(updatedName, updatedEmail, updatedGender, updatedUserType, userId)
        }
    }

    private fun reauthenticateAndUpdateEmail(
        updatedEmail: String, updatedName: String, updatedGender: String, updatedUserType: String, userId: String
    ) {
        val passwordInput = EditText(this)
        passwordInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Re-authenticate")
            .setMessage("Please enter your password to update your email.")
            .setView(passwordInput)
            .setPositiveButton("Confirm") { _, _ ->
                val currentUser = auth.currentUser
                val password = passwordInput.text.toString()
                val credential = EmailAuthProvider.getCredential(currentUser?.email!!, password)

                currentUser.reauthenticate(credential)
                    .addOnSuccessListener {
                        currentUser.updateEmail(updatedEmail)
                            .addOnSuccessListener {
                                updateUserProfile(updatedName, updatedEmail, updatedGender, updatedUserType, userId)
                            }
                            .addOnFailureListener { exception ->
                                Toast.makeText(this, "Failed to update email: ${exception.message}", Toast.LENGTH_LONG).show()
                            }
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(this, "Re-authentication failed: ${exception.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateUserProfile(
        updatedName: String, updatedEmail: String, updatedGender: String, updatedUserType: String, userId: String
    ) {
        val updatedData = mapOf(
            "name" to updatedName,
            "email" to updatedEmail,
            "gender" to updatedGender,
            "userType" to updatedUserType // Include userType in the update
        )

        database.child("Users").child(userId).updateChildren(updatedData)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated successfully.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to update profile: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}