package com.example.milestone1.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.milestone1.adapters.ConsultationAdapter
import com.example.milestone1.databinding.FragmentConsultationBinding
import com.example.milestone1.models.Consultation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ConsultationFragment : Fragment() {
    private var _binding: FragmentConsultationBinding? = null
    private val binding get() = _binding!!
    private lateinit var database: DatabaseReference
    private val consultations = mutableListOf<Consultation>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConsultationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get the currently authenticated user's ID
        val currentUser = FirebaseAuth.getInstance().currentUser
        val patientId = currentUser?.uid ?: run {
            Toast.makeText(context, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        // Set up Firebase Database reference
        database = FirebaseDatabase.getInstance().reference
        binding.rvConsultations.layoutManager = LinearLayoutManager(context)
        val adapter = ConsultationAdapter(consultations)
        binding.rvConsultations.adapter = adapter

        // Fetch consultations for the current patient
        database.child("consultations")
            .orderByChild("patientId").equalTo(patientId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    consultations.clear()
                    for (consultationSnapshot in snapshot.children) {
                        val consultation = consultationSnapshot.getValue(Consultation::class.java)
                        if (consultation != null) {
                            consultations.add(consultation)
                        }
                    }
                    adapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })

        // Handle new consultation message submission
        binding.btnSend.setOnClickListener {
            val message = binding.etMessage.text.toString()
            if (message.isNotEmpty()) {
                val consultationId = database.child("consultations").push().key!!
                val consultation = Consultation(
                    consultationId,
                    patientId,
                    "doctor1", // Replace with actual doctor ID if available
                    message,
                    "",
                    System.currentTimeMillis()
                )
                database.child("consultations").child(consultationId).setValue(consultation)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Consultation sent", Toast.LENGTH_SHORT).show()
                        binding.etMessage.text.clear()
                    }
                    .addOnFailureListener {
                        Toast.makeText(context, "Failed to send consultation", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(context, "Message cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
