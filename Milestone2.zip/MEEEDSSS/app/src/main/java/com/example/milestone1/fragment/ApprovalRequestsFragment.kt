package com.example.milestone1.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import com.example.milestone1.adapters.ApprovalRequestsAdapter
import com.example.milestone1.models.Approval
import com.google.firebase.database.*

class ApprovalRequestsFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ApprovalRequestsAdapter
    private lateinit var database: DatabaseReference


    private val approvalList = mutableListOf<Approval>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_approval_requests, container, false)

        recyclerView = view.findViewById(R.id.rvApprovalRequests)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        database = FirebaseDatabase.getInstance().getReference("approvalRequests")

        adapter = ApprovalRequestsAdapter(approvalList) { approval, isApproved ->
            updateApprovalStatus(approval, isApproved)
        }
        recyclerView.adapter = adapter

        // Load approval requests from Firebase
        loadApprovalRequests()

        return view
    }

    private fun loadApprovalRequests() {
        database.orderByChild("status").equalTo("PENDING").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                approvalList.clear() // Clear the list to avoid duplicates

                for (child in snapshot.children) {
                    try {
                        val approval = child.getValue(Approval::class.java)
                        if (approval != null) {
                            approvalList.add(approval)
                        }
                    } catch (e: Exception) {
                        Log.e("ApprovalRequestsFragment", "Error parsing approval data: ${e.message}")
                    }
                }

                adapter.notifyDataSetChanged() // Update the RecyclerView
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("ApprovalRequestsFragment", "DatabaseError: ${error.message}")
            }
        })
    }



    private fun updateApprovalStatus(approval: Approval, isApproved: Boolean) {
        val status = if (isApproved) "APPROVED" else "REJECTED"
        database.child(approval.id).child("status").setValue(status)
            .addOnSuccessListener {
                Log.d("ApprovalRequestsFragment", "Approval status updated to $status for ${approval.medicationName}")

                // Remove the item from the list and update UI
                approvalList.remove(approval)
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Log.e("ApprovalRequestsFragment", "Failed to update approval status for ${approval.medicationName}")
            }
    }

}