package com.example.milestone1.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.databinding.ItemQuestionBinding
import com.example.milestone1.models.Consultation
import android.graphics.Color

class ConsultationAdapter(
    private val consultations: List<Consultation>,
    private val isDoctor: Boolean = false,
    private val onReply: (Consultation, String) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<ConsultationAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemQuestionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(consultation: Consultation) {
            // Display patient's name, message, and status
            binding.tvSenderName.text = "From: ${consultation.patientName}" // Add sender's name
            binding.tvMessage.text = consultation.message
            binding.tvStatus.text = consultation.status
            if(binding.tvStatus.text=="Completed"){
                binding.tvStatus.setTextColor((Color.GREEN))
            }

            // Display reply if available
            if (consultation.reply.isNotEmpty()) {
                binding.tvReply.visibility = View.VISIBLE
                binding.tvReply.text = "Reply: ${consultation.reply}"
            } else {
                binding.tvReply.visibility = View.GONE
            }

            // Show reply input if the user is a doctor
            if (isDoctor) {
                binding.llReplyInput.visibility = View.VISIBLE
                binding.btnReply.setOnClickListener {
                    val replyText = binding.etReply.text.toString()
                    if (replyText.isNotEmpty()) {
                        onReply(consultation, replyText)
                        binding.etReply.text.clear()
                    }
                }
            } else {
                binding.llReplyInput.visibility = View.GONE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemQuestionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(consultations[position])
    }

    override fun getItemCount(): Int = consultations.size
}
