package com.example.milestone1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.milestone1.fragment.ConsultationFragment
import com.example.milestone1.fragment.adweyahFragment
//import com.example.milestone1.fragment.roshetaFragment

class profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)

        // Retrieve the username from the intent
        val userName = intent.getStringExtra("USERNAME")

        // Find the TextView by its ID
        val nameTextView = findViewById<TextView>(R.id.name)

        // If the username is not null, update the TextView with the user's name
        if (!userName.isNullOrEmpty()) {
            nameTextView.text = userName
        }

        val mapimage = findViewById<ImageView>(R.id.imageinbox2)
        val more = findViewById<ImageView>(R.id.imageinbox8)
        val setting = findViewById<ImageView>(R.id.imageinbox7)
        val tips = findViewById<ImageView>(R.id.imageinbox6)
        val rosheta = findViewById<ImageView>(R.id.imageinbox5)
        val consultation = findViewById<ImageView>(R.id.imageinbox3)





        mapimage.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivity(intent)
        }

        more.setOnClickListener {
            val intent = Intent(this, save::class.java)
            startActivity(intent)
        }

        setting.setOnClickListener {
            val intent = Intent(this, settings::class.java)
            startActivity(intent)
        }

        tips.setOnClickListener {
            // Replace the current fragment with MyFragment
            replaceFragment(adweyahFragment())
        }
        rosheta.setOnClickListener {
            // Replace the current fragment with MyFragment
            //replaceFragment(roshetaFragment())
        }
        consultation.setOnClickListener {
            // Replace the current fragment with MyFragment
            replaceFragment(ConsultationFragment())
        }

    }
    private fun replaceFragment(fragment: Fragment) {
        // Start a FragmentTransaction
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment) // Replace the fragment
        transaction.addToBackStack(null) // Add to back stack
        transaction.commit() // Commit the transaction
    }

}

