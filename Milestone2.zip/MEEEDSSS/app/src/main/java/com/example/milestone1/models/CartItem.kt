package com.example.milestone1.models

data class CartItem(
    val medication: Medication,
    var quantity: Int
)