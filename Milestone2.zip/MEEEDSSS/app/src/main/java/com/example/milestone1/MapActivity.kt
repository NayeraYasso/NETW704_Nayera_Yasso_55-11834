package com.example.milestone1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load the layout
        setContentView(R.layout.activity_map)

        // Initialize OsmDroid configuration
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))

        // Find the MapView in the layout
        mapView = findViewById(R.id.map)

        // Set up the map view
        mapView.setMultiTouchControls(true) // Enable pinch to zoom

        // Set initial zoom and position to GUC location
        val gucLocation = GeoPoint(29.98597610893286, 31.438814450992723) // GUC coordinates
        mapView.controller.setZoom(15.0) // Set the zoom level
        mapView.controller.setCenter(gucLocation) // Set the center of the map

        // Add a marker for GUC Clinic
        val clinicMarker = Marker(mapView)
        clinicMarker.position = gucLocation
        clinicMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        clinicMarker.title = "GUC Clinic"
        clinicMarker.subDescription = "Clinic within the German University in Cairo"
        mapView.overlays.add(clinicMarker)

        // Add a marker for a nearby drugstore
        val drugstoreLocation = GeoPoint(29.9867, 31.4405) // Example coordinates for drugstore
        val drugstoreMarker = Marker(mapView)
        drugstoreMarker.position = drugstoreLocation
        drugstoreMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        drugstoreMarker.title = "Nearby Drugstore"
        drugstoreMarker.subDescription = "Drugstore near GUC campus"
        mapView.overlays.add(drugstoreMarker)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume() // Needed for compass, my location overlays, etc.
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause() // Needed for compass, my location overlays, etc.
    }
}
