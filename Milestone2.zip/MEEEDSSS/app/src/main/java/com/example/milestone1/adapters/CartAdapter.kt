package com.example.milestone1.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import com.example.milestone1.models.CartItem

class CartAdapter(
    private val cartItems: MutableList<CartItem>,
    private val onRemove: (CartItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cartItemName: TextView = view.findViewById(R.id.cartItemName)
        val cartItemQuantity: TextView = view.findViewById(R.id.cartItemQuantity)
        val removeButton: Button = view.findViewById(R.id.removeButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemcart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartItems[position]
        holder.cartItemName.text = cartItem.medication.name
        holder.cartItemQuantity.text = "${cartItem.quantity}x"

        holder.removeButton.setOnClickListener {
            onRemove(cartItem)
        }
    }

    override fun getItemCount() = cartItems.size
}