package com.example.milestone1.fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.example.milestone1.R
import com.example.milestone1.m2.Doctor
import com.example.milestone1.models.Medication
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class AddMedication : Fragment() {

    private lateinit var medicationImage: ImageView
    private lateinit var database: DatabaseReference
    private lateinit var storageRef: StorageReference
    private var imageUri: Uri? = null
    private var cameraPhotoPath: String? = null

    private lateinit var galleryLauncher: ActivityResultLauncher<String>
    private lateinit var cameraLauncher: ActivityResultLauncher<Uri>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_medication, container, false)

        // Initialize Firebase Storage and Database references
        storageRef = FirebaseStorage.getInstance().getReference("Medications")
        database = FirebaseDatabase.getInstance().getReference("Medications")

        // Initialize Views
        medicationImage = view.findViewById(R.id.medicationImage)
        val nameInput = view.findViewById<EditText>(R.id.medicationName)
        val quantityInput = view.findViewById<EditText>(R.id.medicationQuantity)
        val priceInput = view.findViewById<EditText>(R.id.medicationPrice)
        val saveButton = view.findViewById<Button>(R.id.saveButton)
        val back = view.findViewById<ImageView>(R.id.backarrow)

        // Initialize launchers for gallery and camera
        galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                imageUri = uri
                medicationImage.setImageURI(uri)
            }
        }

        cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && cameraPhotoPath != null) {
                imageUri = Uri.fromFile(File(cameraPhotoPath))
                medicationImage.setImageURI(imageUri)
            } else {
                Toast.makeText(context, "Camera capture failed.", Toast.LENGTH_SHORT).show()
            }
        }

        back.setOnClickListener {
            val intent = Intent(requireContext(), Doctor::class.java)
            startActivity(intent)
        }

        // Set click listener on ImageView to open gallery or camera
        medicationImage.setOnClickListener {
            showImageSourceOptions()
        }

        // Set click listener on save button to save data to Firebase
        saveButton.setOnClickListener {
            val name = nameInput.text.toString()
            val quantity = quantityInput.text.toString()
            val price = priceInput.text.toString()

            if (name.isNotEmpty() && quantity.isNotEmpty() && price.isNotEmpty()) {
                saveMedicationData(name, quantity.toInt(), price.toDouble())
            } else {
                Toast.makeText(context, "Please fill in all the fields.", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun showImageSourceOptions() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Select Image Source")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> requestCameraPermission()
                    1 -> galleryLauncher.launch("image/*")
                }
            }
            .show()
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
        } else {
            openCamera() // Open camera if permission is already granted
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                Toast.makeText(context, "Camera permission is required to take a photo.", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun openCamera() {
        try {
            val photoFile = createImageFile() // Method to create a temporary image file
            val photoUri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.provider",
                photoFile
            )
            cameraPhotoPath = photoFile.absolutePath
            cameraLauncher.launch(photoUri) // Launch the camera
        } catch (ex: IOException) {
            Toast.makeText(context, "Error creating image file: ${ex.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageFile(): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = requireActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timestamp}_", ".jpg", storageDir)
    }


    private fun saveMedicationData(name: String, quantity: Int, price: Double) {
        val medicationId = database.push().key ?: return

        // Ensure there is an image URI
        if (imageUri != null) {
            val imageUrl = imageUri.toString() // Convert URI to string for storage in the database

            // Create Medication object with local image URI
            val medication = Medication(medicationId, name, quantity, price, imageUrl)

            // Save medication to the database
            database.child(medicationId).setValue(medication)
                .addOnSuccessListener {
                    Toast.makeText(context, "Medication saved successfully.", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(context, "Failed to save medication: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(context, "Please select an image.", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 101
    }
}
