package com.example.milestone1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.milestone1.m2.Doctor
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.database.FirebaseDatabase

class login : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        val usernameInput = findViewById<EditText>(R.id.email)
        val passwordInput = findViewById<EditText>(R.id.password)
        val loginButton = findViewById<ImageView>(R.id.loginbut)

        loginButton.setOnClickListener {
            val userEmail = usernameInput.text.toString()
            val userPassword = passwordInput.text.toString()

            if (userEmail.isNotEmpty() && userPassword.isNotEmpty()) {
                signIn(userEmail, userPassword)
            } else {
                Toast.makeText(this, "email and password cannot be empty.", Toast.LENGTH_SHORT).show()
            }
        }

        val forgetTextView = findViewById<TextView>(R.id.textreg)
        forgetTextView.setOnClickListener {
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        }
    }

    private fun signIn(userEmail: String, userPassword: String) {
        auth.signInWithEmailAndPassword(userEmail, userPassword)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, get user ID
                    val userId = auth.currentUser?.uid

                    if (userId != null) {
                        // Initialize Firebase Database reference
                        val database = FirebaseDatabase.getInstance().getReference("Users")

                        // Retrieve user details, including userType
                        database.child(userId).get()
                            .addOnSuccessListener { dataSnapshot ->
                                // Retrieve the userType and additional fields
                                val userType = dataSnapshot.child("userType").getValue(String::class.java)
                                val userName = dataSnapshot.child("name").getValue(String::class.java)
                                val userEmail = dataSnapshot.child("email").getValue(String::class.java)
                                val userGender = dataSnapshot.child("gender").getValue(String::class.java)

                                if (userType != null) {
                                    // Choose activity based on userType
                                    val intent = if (userType.lowercase() == "doctor") {
                                        Intent(this, Doctor::class.java)
                                    } else if (userType.lowercase() == "patient") {
                                        Intent(this, profile::class.java)
                                    } else {
                                        Toast.makeText(this, "Unknown user type. Please contact support.", Toast.LENGTH_SHORT).show()
                                        return@addOnSuccessListener
                                    }

                                    // Pass additional user details to the chosen activity
                                    intent.putExtra("name", userName)
                                    intent.putExtra("email", userEmail)
                                    intent.putExtra("gender", userGender)
                                    intent.putExtra("userType", userType)

                                    startActivity(intent)
                                    finish()
                                } else {
                                    Toast.makeText(this, "User type not found. Please sign up again.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Failed to retrieve user data: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(this, "User ID is null. Please try logging in again.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // Handle sign-in failure
                    val exception = task.exception
                    when (exception) {
                        is FirebaseAuthInvalidUserException -> {
                            Toast.makeText(this, "Email not registered. Please sign up first.", Toast.LENGTH_SHORT).show()
                        }
                        is FirebaseAuthInvalidCredentialsException -> {
                            Toast.makeText(this, "Incorrect password. Please try again.", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            Toast.makeText(this, "Authentication failed: ${exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    exception?.printStackTrace()
                }
            }
    }

}
